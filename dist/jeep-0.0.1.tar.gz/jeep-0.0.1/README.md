# 1961 CJ-3B

## Installation

Start with a virtualenv:

    $ python3 -m venv env
    $ source ./env/bin/activate

Then install things

    (env) $ pip install -r requirements.txt

[![Build Status](https://travis-ci.org/zachseifts/jeeps.svg?branch=travis-config)](https://travis-ci.org/zachseifts/jeeps)

* [1944 MB](https://github.com/44mb/issues/issues)
* [1960 CJ-3B](https://github.com/zachseifts/jeeps/wiki/1960-CJ-3B)
